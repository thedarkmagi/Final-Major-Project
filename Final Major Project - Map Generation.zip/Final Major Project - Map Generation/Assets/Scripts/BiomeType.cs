﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public enum BiomeType { ocean, water, land, mountain};
